const { Aki } = require('aki-api')
const fs = require('fs')

let handler = async (NanoBotz, m, { usedPrefix, command, args }) => {
    NanoBotz.akinator = NanoBotz.akinator || {}
    let room = NanoBotz.akinator[m.sender]

    switch ((args[0] || '').toLowerCase()) {
        case 'start': {
            if (room) return m.reply('Kamu masih di sesi Akinator!\nKetik *.akinator end* untuk keluar.')
            NanoBotz.akinator[m.sender] = new Aki({ region: 'id' })
            await NanoBotz.akinator[m.sender].start()
            let { question } = NanoBotz.akinator[m.sender]
            let teks = `🎮 *Akinator* 🎮\n\n@${m.sender.split('@')[0]}\n${question}\n\n`
            teks += `Jawab:\n*.akinator answer 0* = Ya\n*.akinator answer 1* = Tidak\n*.akinator answer 2* = Tidak Tahu\n*.akinator answer 3* = Mungkin\n*.akinator answer 4* = Mungkin Tidak\n\nKetik *.akinator end* untuk keluar.`
            NanoBotz.akinator[m.sender].chat = await NanoBotz.sendMessage(m.chat, { text: teks, mentions: [m.sender] }, { quoted: m })
            NanoBotz.akinator[m.sender].waktu = setTimeout(() => {
                NanoBotz.sendMessage(m.chat, { text: 'Waktu habis, sesi Akinator ditutup.' }, { quoted: m })
                delete NanoBotz.akinator[m.sender]
            }, 60000)
        }
            break

        case 'end': {
            if (!room) return m.reply('Tidak ada sesi Akinator aktif.')
            delete NanoBotz.akinator[m.sender]
            m.reply('Sesi Akinator dihentikan.')
        }
            break

        case 'answer': {
            if (!room) return m.reply('Mulai dulu dengan *.akinator start*')
            if (!args[1] || !/^[0-4]$/.test(args[1])) return m.reply('Masukkan jawaban 0–4 (Ya/Tidak/Tidak Tahu/Mungkin/Mungkin Tidak)')
            clearTimeout(room.waktu)
            await room.step(Number(args[1]))
            if (room.progress >= 80 || room.currentStep >= 78) {
                await room.win()
                let g = room.answers[0]
                let cap = `Aku Menebak:\n\n*${g.name}*\n_${g.description}_\n\nBenar gak?\nKetik *.akinator start* untuk main lagi.`
                await NanoBotz.sendMessage(m.chat, { image: { url: g.absolute_picture_path }, caption: cap }, { quoted: m })
                delete NanoBotz.akinator[m.sender]
            } else {
                let t = `@${m.sender.split('@')[0]}\nStep ${room.currentStep} (${room.progress.toFixed(1)}%)\n\n${room.question}\n\nJawab dengan:\n*.akinator answer 0* - Ya\n*.akinator answer 1* - Tidak\n*.akinator answer 2* - Tidak Tahu\n*.akinator answer 3* - Mungkin\n*.akinator answer 4* - Mungkin Tidak`
                NanoBotz.akinator[m.sender].chat = await NanoBotz.sendMessage(m.chat, { text: t, mentions: [m.sender] }, { quoted: m })
                NanoBotz.akinator[m.sender].waktu = setTimeout(() => {
                    NanoBotz.sendMessage(m.chat, { text: 'Waktu habis!' }, { quoted: m })
                    delete NanoBotz.akinator[m.sender]
                }, 60000)
            }
        }
            break

        default: {
            let intro = `Permainan Akinator adalah game tebak karakter dari pikiran kamu.\n\nGunakan perintah:\n`
            intro += `• *.akinator start* — mulai game\n`
            intro += `• *.akinator answer <0-4>* — menjawab\n`
            intro += `• *.akinator end* — keluar dari sesi`
            return NanoBotz.sendMessage(m.chat, { text: intro }, { quoted: m })
        }
    }
}

handler.command = /^akinator$/i
handler.tags = ['game']
handler.help = ['akinator']
handler.limit = true
handler.onlyprem = true
handler.game = true

module.exports = handler